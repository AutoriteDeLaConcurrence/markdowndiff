## Markdowndiff

This library provides diff capabilities for parsed markdown text.

# Installation    
You can either install from source or from a built wheel.
To install from source, use ```git clone``` and  ```pip install .``` in the root directory
To install from a prebuilt wheel file, use :
```wget https://github.com/AutoriteDeLaConcurrence/markdowndiff/dist/markdowndiff-0.0.1-py3-none-any.whl```
and ```pip install markdowndiff-0.0.1-py3-none-any.whl```

# Quick use    
Import the modules you will use from the package : 
	from markdowndiff import main, html_formatter

You can then diff markdown texts in the following way :
```
diff = main.diff_from_texts(
	oldText,
	newText,
	markdown_parse=markdown_parse,
	diff_options={"F": 0.5, "fast_match": True},
	formatter=formatter,
	diff_body_only = True
)
```
You need to provide the following arguments:
*	First and second positionnal arguments : the old and the new version of the text
*	```markdown_parse``` : a function to turn markdown text into an html tree
*	```diff_options``` : Options to fine-tune the diffing process
*	```formatter``` : Handles the way the result is displayed. ```html_formatter.HTMLFormatter.getDefault()``` is a good starting point
*	```diff_body_only``` : Is the diff computed on the whole html tree or only the body.

The result of diff_from_texts is a lxml tree. To get a standalone - and pretty - html result, use :
```main.display_diff_html(diff, title, stylesheets)```
You will need to provide the document title, and stylesheets for markdown and diff content. See ```data``` directory for examples.

# Demo    
A demo is currently being built

# Contributions    
This repository builds on the implementation of ["Change Detection in Hierarchically Structured Information"](http://ilpubs.stanford.edu/115/1/1995-46.pdf) provided by [xmldiff](https://github.com/Shoobx/xmldiff).
