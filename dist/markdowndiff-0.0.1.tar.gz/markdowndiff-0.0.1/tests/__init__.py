# Make the tests a module, so we they are discoverable
