import unittest

from lxml import etree
from markdowndiff import formatting, placeholder, html_formatter

DIFF_NS = "http://namespaces.shoobx.com/diff"
DIFF_PREFIX = "diff"

START = '<document xmlns:diff="http://namespaces.shoobx.com/diff"><node'
END = "</node></document>"


class PlaceholderMakerTests(unittest.TestCase):
    def test_get_placeholder(self):
        replacer = placeholder.PlaceholderMaker()
        # Get a placeholder:
        ph = replacer.get_placeholder(etree.Element("tag"), replacer.T_OPEN, None)
        self.assertEqual(ph, "\ue005")
        # Do it again:
        ph = replacer.get_placeholder(etree.Element("tag"), replacer.T_OPEN, None)
        self.assertEqual(ph, "\ue005")
        # Get another one
        ph = replacer.get_placeholder(etree.Element("tag"), replacer.T_CLOSE, ph)
        self.assertEqual(ph, "\ue006")

    def test_do_element(self):
        replacer = placeholder.PlaceholderMaker(["p"], ["b"])

        # Formatting tags get replaced, and the content remains
        text = "<p>This is a tag with <b>formatted</b> text.</p>"
        element = etree.fromstring(text)
        replacer.do_element(element)

        self.assertEqual(
            etree.tounicode(element),
            "<p>This is a tag with \ue006formatted\ue005 text.</p>",
        )

        replacer.undo_element(element)
        self.assertEqual(etree.tounicode(element), text)

        # Non formatting tags do not get replaced
        text = "<p>This is a tag with <foo>formatted</foo> text.</p>"
        element = etree.fromstring(text)
        replacer.do_element(element)
        result = etree.tounicode(element)
        self.assertEqual(result, "<p>This is a tag with <foo>formatted</foo> text.</p>")

        # Single formatting tags still get two placeholders.
        text = "<p>This is a <b/> with <foo/> text.</p>"
        element = etree.fromstring(text)
        replacer.do_element(element)
        result = etree.tounicode(element)
        self.assertEqual(result, "<p>This is a \ue008\ue007 with <foo/> text.</p>")

    def test_do_undo_element(self):
        replacer = placeholder.PlaceholderMaker(["p"], ["b"])

        # Formatting tags get replaced, and the content remains
        text = "<p>This <is/> a <f>tag</f> with <b>formatted</b> text.</p>"
        element = etree.fromstring(text)
        replacer.do_element(element)

        self.assertEqual(element.text, "This ")

        replacer.undo_element(element)
        result = etree.tounicode(element)
        self.assertEqual(result, text)

    def test_do_undo_element_double_format(self):
        replacer = placeholder.PlaceholderMaker(["p"], ["b", "u"])

        # Formatting tags get replaced, and the content remains
        text = "<p>This is <u>doubly <b>formatted</b></u> text.</p>"
        element = etree.fromstring(text)
        replacer.do_element(element)

        self.assertEqual(
            element.text, "This is \ue008doubly \ue006formatted\ue005" "\ue007 text."
        )

        replacer.undo_element(element)
        result = etree.tounicode(element)
        self.assertEqual(result, text)

    def test_rml_bug(self):
        etree.register_namespace(formatting.DIFF_PREFIX, formatting.DIFF_NS)
        before_diff = """<document xmlns:diff="http://namespaces.shoobx.com/diff">
                          <section>
                            <para>
                              <ref>4</ref>.
                              <u><b>At Will Employment</b></u>
                              .\u201cText\u201d
                            </para>
                          </section>
                        </document>"""
        tree = etree.fromstring(before_diff)
        replacer = placeholder.PlaceholderMaker(
            text_tags=("para",), formatting_tags=("b", "u", "i",),
        )
        replacer.do_tree(tree)
        after_diff = """<document xmlns:diff="http://namespaces.shoobx.com/diff">
                          <section>
                            <para>
                              <insert><ref>4</ref></insert>.
                              \ue008\ue006At Will Employment\ue005\ue007
                              .\u201c<insert>New </insert>Text\u201d
                            </para>
                          </section>
                        </document>"""

        # The diff formatting will find some text to insert.
        delete_attrib = "{%s}delete-format" % formatting.DIFF_NS
        replacer.placeholder2tag["\ue008"].element.attrib[delete_attrib] = ""
        replacer.placeholder2tag["\ue005"].element.attrib[delete_attrib] = ""
        tree = etree.fromstring(after_diff)
        replacer.undo_tree(tree)
        result = etree.tounicode(tree)
        expected = """<document xmlns:diff="http://namespaces.shoobx.com/diff">
                          <section>
                            <para>
                              <insert><ref>4</ref></insert>.
                              <u diff:delete-format=""><b>At Will Employment</b></u>
                              .\u201c<insert>New </insert>Text\u201d
                            </para>
                          </section>
                        </document>"""
        self.assertEqual(result, expected)


class HTMLPlaceholderMakerTests(unittest.TestCase):
    def test_get_placeholder(self):
        replacer = placeholder.HTMLPlaceholderMaker.getDefault()
        # Get a placeholder:
        ph = replacer.get_placeholder(etree.Element("tag"), replacer.T_OPEN, None)
        self.assertEqual(ph, "\ue005")
        # Do it again:
        ph = replacer.get_placeholder(etree.Element("tag"), replacer.T_OPEN, None)
        self.assertEqual(ph, "\ue005")
        # Get another one
        ph = replacer.get_placeholder(etree.Element("tag"), replacer.T_CLOSE, ph)
        self.assertEqual(ph, "\ue006")

    def test_do_undo_element_double_format(self):
        replacer = placeholder.HTMLPlaceholderMaker.getDefault()

        # Formatting tags get replaced, and the content remains
        text = "<p>This is <b>doubly <b>formatted</b></b> text.</p>"
        element = etree.fromstring(text)
        replacer.do_element(element)

        self.assertEqual(
            element.text, "This is \ue006doubly \ue006formatted\ue005" "\ue005 text."
        )

        replacer.undo_element(element)
        result = etree.tounicode(element)
        self.assertEqual(result, text)

    def test_complex_case(self):
        replacer = placeholder.HTMLPlaceholderMaker.getDefault()
        # Formatting tags get replaced, and the content remains
        text = """<body>
          <div id="id">
            <p>
              A common prefix helps the matching a lot. This is some simple text demonstrating the features of the <b>human text
              differ</b>. This <u><em>feature</em></u> attempts to make changelog nice &amp; readable for
              humans. <br/>The human text differ uses sentences as its first order
              matching. Let's see.
            </p>
          </div>
        </body>"""

        element = etree.fromstring(text)
        replacer.do_tree(element)
        self.maxDiff = None
        replaced_text = """<body>
          <div id="id">
            <p>
              A common prefix helps the matching a lot. This is some simple text demonstrating the features of the \ue006human text
              differ\ue005. This \ue00a\ue008feature\ue007\ue009 attempts to make changelog nice &amp; readable for
              humans. \ue00bThe human text differ uses sentences as its first order
              matching. Let's see.
            </p>
          </div>
        </body>"""
        self.assertEqual(etree.tounicode(element), replaced_text)
        replacer.undo_tree(element)
        result = etree.tounicode(element)
        self.assertEqual(result, text)

    def test_dual_formatting(self):
        replacer = placeholder.HTMLPlaceholderMaker.getDefault()
        text = """<p>begin text <b> bold text </b> tail <em>emphasis <u>and underline</u></em> and another <b>text in bold</b></p>"""
        replaced_text = """begin text \ue006 bold text \ue005 tail \ue00aemphasis \ue008and underline\ue007\ue009 and another \ue006text in bold\ue005"""
        tree = etree.fromstring(text)
        replacer.do_tree(tree)
        self.assertEqual(tree.text, replaced_text)

    def test_realign_simple(self):
        placeholdermaker = placeholder.HTMLPlaceholderMaker.getDefault()

        # here we test removal of formatting (b tag) and movement for the beginning of formaating (u tag)

        text = """<p>begin text <b> bold text </b> tail <em> big emphasis <u> and underline </u></em> and another <b> text in bold</b></p>"""
        test_diff = [
            (0, "begin text "),
            (0, "\ue006"),
            (0, "bold text "),
            (0, "\ue005"),
            (0, " tail "),
            (0, "\ue00a"),
            (1, "\ue008"),
            (0, "big emphasis"),
            (-1, "\ue008"),
            (0, "and underline"),
            (0, "\ue007"),
            (0, "\ue009"),
            (0, "and another"),
            (-1, "\ue006"),
            (0, "text in bold"),
            (-1, "\ue005"),
        ]
        modified_part = [(1, "\ue007"), (0, "\ue008")]

        tree = etree.fromstring(text)
        placeholdermaker.do_tree(tree)  # this initializes the placeholder
        realigned_diff = placeholdermaker.realign_placeholders(test_diff)

        self.assertEqual(test_diff[0:8], realigned_diff[0:8])
        self.assertEqual(test_diff[9:16], realigned_diff[10:17])
        self.assertEqual(realigned_diff[8:10], modified_part)

    def test_realign_complex(self):
        # in this test we change the order of two formatting, and change beginning and end of formatting for another tag
        placeholdermaker = placeholder.HTMLPlaceholderMaker.getDefault()
        text = """<p>begin <em> big emphasis <u> and underline </u></em> and another <b>text in bold</b></p>"""
        replaced_text = """begin \ue008 big emphasis \ue006 and underline \ue005\ue007 and another \ue00atext in bold\ue009"""

        test_diff = [
            (1, "\ue006"),
            (0, "begin"),
            (0, "\ue008"),
            (0, "big emphasis"),
            (-1, "\ue006"),
            (0, "and underline"),
            (1, "\ue007"),
            (0, "\ue005"),
            (-1, "\ue007"),
            (0, "and another"),
            (-1, "\ue00a"),
            (0, "text"),
            (1, "\ue00a"),
            (0, "in"),
            (1, "\ue009"),
            (0, "bold"),
            (-1, "\ue009"),
        ]

        modified_part = [
            (0, "\ue007"),
            (1, "\ue005"),
            (0, "\ue006"),
            (0, "\ue008"),
            (0, "and underline"),
            (0, "\ue007"),
            (-1, "\ue008"),
            (-1, "\ue007"),
            (0, "\ue005"),
            (-1, "\ue008"),
            (-1, "\ue007"),
            (0, "and another"),
            (-1, "\ue00a"),
            (0, "text"),
            (-1, "\ue009"),
            (0, "\ue00a"),
            (0, "in"),
            (0, "\ue009"),
            (-1, "\ue00a"),
        ]

        tree = etree.fromstring(text)  # this initializes the placeholder
        placeholdermaker.do_tree(tree)
        self.assertEqual(
            tree.text, replaced_text
        )  # otherwise the rest of the test does not make sense

        realigned_diff = placeholdermaker.realign_placeholders(test_diff)

        self.assertEqual(len(realigned_diff), 25)
        self.assertEqual(test_diff[0:4], realigned_diff[0:4])
        self.assertEqual(test_diff[15:17], realigned_diff[23:25])
        self.assertEqual(realigned_diff[4:23], modified_part)

    def get_html_formatted_diff(self, left_text, right_text):
        formatter = html_formatter.HTMLFormatter(  # Create a new one each time to have a new placeholder maker
            text_tags=("p", "h1", "h2", "h3", "h4", "h5", "h6", "li", "td", "para"),
            dual_formatting_tags=(
                "b",
                "u",
                "i",
                "strike",
                "em",
                "super",
                "sup",
                "sub",
                "span",
                "strong",
            ),
            single_formatting_tags=("br", "hr"),
            complex_formatting_tags=("a", "link"),
            normalize=formatting.WS_BOTH,
            pretty_print=True,
        )

        tree = etree.fromstring(left_text)
        formatter.placeholderer.do_tree(tree)
        text_before = tree.text

        tree2 = etree.fromstring(right_text)
        formatter.placeholderer.do_tree(tree2)
        text_after = tree2.text

        formatter._make_diff_tags(text_before, text_after, tree, False)
        formatter.placeholderer.undo_tree(tree)

        etree.register_namespace(DIFF_PREFIX, DIFF_NS)
        etree.cleanup_namespaces(tree, top_nsmap={DIFF_PREFIX: DIFF_NS})
        return etree.tounicode(tree)

    def test_diff_process(self):
        text = """<p>another <b> text in a lot of bold</b> and yet some more <b>bold</b></p>"""
        text2 = """<p>another text <b>in a lot</b> of bold and yet <b>some more bold</b></p>"""
        expected = """<p xmlns:diff="http://namespaces.shoobx.com/diff">another <b diff:delete-formatting="">text</b> <b> in a lot </b> <b diff:delete-formatting="">of bold</b> and yet <b diff:insert-formatting="">some more</b> <b> bold </b></p>"""

        result = self.get_html_formatted_diff(text, text2)
        self.assertEqual(result, expected)

    def test_edge_case(self):
        text1 = """<p>**<strong>10.2 QUELLES DONNÉES SONT TRAITEES PAR FLOA ET CDISCOUNT ?</strong></p>"""
        text2 = """<p><strong><strong>10.2 QUELLES DONNÉES SONT TRAITEES PAR FLOA ET CDISCOUNT ?</strong></strong></p>"""
        expected = """<p xmlns:diff="http://namespaces.shoobx.com/diff"><diff:delete>**</diff:delete> <strong diff:insert-formatting=""><strong> 10.2 QUELLES DONNÉES SONT TRAITEES PAR FLOA ET CDISCOUNT ? </strong></strong></p>"""

        formatter = html_formatter.HTMLFormatter(  # Create a new one each time to have a new placeholder maker
            text_tags=("p", "h1", "h2", "h3", "h4", "h5", "h6", "li", "td", "para"),
            dual_formatting_tags=(
                "b",
                "u",
                "i",
                "strike",
                "em",
                "super",
                "sup",
                "sub",
                "span",
                "strong",
            ),
            single_formatting_tags=("br", "hr"),
            complex_formatting_tags=("a", "link"),
            normalize=formatting.WS_BOTH,
            pretty_print=True,
        )

        tree = etree.fromstring(text1)
        formatter.placeholderer.do_tree(tree)
        text_before = tree.text

        tree2 = etree.fromstring(text2)
        formatter.placeholderer.do_tree(tree2)
        text_after = tree2.text

        formatter._make_diff_tags(text_before, text_after, tree, False)
        formatter.placeholderer.undo_tree(tree)

        etree.register_namespace(DIFF_PREFIX, DIFF_NS)
        etree.cleanup_namespaces(tree, top_nsmap={DIFF_PREFIX: DIFF_NS})


        self.assertEqual(etree.tounicode(tree), expected)
